
Choose access rights for this folder carefully!

The DIZApp supports authentication to FHIR servers by Basic Auth, Client Cert Auth or No Auth.
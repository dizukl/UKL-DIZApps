
Choose access rights for this folder carefully!

The DIZApp only supports authentication to FHIR servers by Basic Auth or No Auth.